#include "common.h"
#include "socket.h"

int server_fd, client_fd;
struct sockaddr_in server_addr, client_addr;
socklen_t client_len;
char buffer[BUF_SIZE] = {0};


int main()
{
	Fn_MENU();
	Fn_SOCKET();

	return 0;
}

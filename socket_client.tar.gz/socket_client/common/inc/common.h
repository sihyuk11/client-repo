#ifndef COMMON_H_
#define COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define MAX         1024
#define PORT        9090
#define BUF_SIZE    1024



typedef struct book
{
	int data[MAX];
	int count;
	struct book *prev;
	struct book *next;
}list;






extern list *head;
extern list *tail;



void Fn_MENU();






#endif //COMMON_H_

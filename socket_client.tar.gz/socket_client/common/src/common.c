#include "common.h"


void Fn_MENU()
{
	printf("--------------------------------\r\n");


	return;
}




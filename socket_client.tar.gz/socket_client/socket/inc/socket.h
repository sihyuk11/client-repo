#ifndef SOCK_H_
#define SOCK_H_

#include "common.h"

int Fn_SOCKET();

extern int server_fd, client_fd;
extern struct sockaddr_in server_addr, client_addr;
extern socklen_t client_len;
extern char buffer[BUF_SIZE];


#endif //SOCK_H_




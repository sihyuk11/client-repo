#include "socket.h"

int Fn_SOCKET()
{

    int sock;

    struct sockaddr_in server_addr;

    char buffer[BUF_SIZE];

    char *server_ip;
    char *server_port_env;

    int server_port;

    server_ip = getenv("SERVER_HOST");

    if (server_ip == NULL)
    {
        server_ip = "tcp-server";
    }

    server_port_env = getenv("SERVER_PORT");

    if (server_port_env == NULL)
    {
        server_port = 9090;
    }
    else
    {
        server_port = atoi(server_port_env);
    }

    while (1)
    {
        sock = socket(AF_INET, SOCK_STREAM, 0);

        if (sock < 0)
        {
            perror("socket");

            sleep(3);

            continue;
        }

        memset(&server_addr, 0, sizeof(server_addr));

        server_addr.sin_family = AF_INET;

        server_addr.sin_port = htons(server_port);

        inet_pton(AF_INET, server_ip, &server_addr.sin_addr);

        printf("[INFO] connect -> %s:%d\n", server_ip, server_port);

        if (connect(sock,
                    (struct sockaddr *)&server_addr,
                    sizeof(server_addr)) < 0)
        {
            perror("connect");

            close(sock);

            sleep(3);

            continue;
        }

        printf("[INFO] connected\n");

        while (1)
        {
            char *message = "hello server";

            send(sock,
                 message,
                 strlen(message),
                 0);

            memset(buffer, 0, BUF_SIZE);

            int recv_len;

            recv_len = recv(sock,
                            buffer,
                            BUF_SIZE - 1,
                            0);

            if (recv_len <= 0)
            {
                printf("[ERROR] disconnected\n");

                close(sock);

                break;
            }

            printf("[RECV] %s\n", buffer);

            sleep(5);
        }
    }

    return 0;
}
